clc
clear
addpath('...\ClusteringMeasure');
for i = 1
Name={'Yale','JAFFE','ORL','UMIST','Reuters','Hdigit','COIL20','COIL100','ALOI','Mfeet','CIFAR10','CIFAR100','FMNIST','MNIST','MNIST2'};
Name2={'Yale_32x32.mat','JAFFE_64x64.mat','ORL_32x32.mat',...
    'UMIST.mat','Reuters.mat',...
    'UCI_Digits.mat','COIL20.mat','COIL100.mat',...
    'ALOI.mat','Mfeat.mat',...
    'cifar10_Per1','cifar100_Per1','fmnist_Per1','MNIST_fea_Per1','MNIST_fea_sort_Per1'};

load(Name2{i})
fea=double(fea);
gnd=double(gnd);
total=unique(gnd);
num_cluster=length(total);
num_sample=length(gnd);
if size(fea,1)~=num_sample
    fea=fea';
end
if strcmp(Name{i},'BBC') || strcmp(Name{i},'Reuters') || strcmp(Name{i},'BDGP') || strcmp(Name{i},'CiteSeer')
ax=full(max(max(fea)));
in=full(min(min(fea)));
for iii=1:num_cluster
    [n,~]=find(gnd==total(num_cluster));
    for j=n(end-floor(length(gnd)*0.1/num_cluster)):n(end)%j=n(1):n(round(length(gnd)*0.3/nr))
        img=full(fea(j,:));
        order_noise=randperm(length(img),floor(0.8*length(img)));
        salt=round(rand(1,floor(0.8*length(img))),0);
        pepper=1-salt;
        img(logical(salt)) = ax;
        img(logical(pepper)) = in;
        fea=[fea;sparse(img)];
        if size(gnd,1)==1
            gnd=[gnd,total(end)+1];
        else
            gnd=[gnd;total(end)+1];
        end
    end
end
else
for iii=1:num_cluster
    [n,~]=find(gnd==total(num_cluster));
    for j=n(end-floor(length(gnd)*0.1/num_cluster)):n(end)%j=n(1):n(round(length(gnd)*0.3/nr))
        img=uint8(full(fea(j,:)));
        img = imnoise(img,'salt & pepper',0.8);
        fea=[fea;double(img)];
        if size(gnd,1)==1
            gnd=[gnd,total(end)+1];
        else
            gnd=[gnd;total(end)+1];
        end
    end
end
end
clear n img j iii total
r=1;
c=1;
time=0;
cc=1;
for k_rcan = 2:25
    for lambda=[0.00001,0.0001,0.001,0.01,0.1,1,10,100,1000,10000]
        tic
        [ ~,  order_outlier, la_rcan] = RCAL_batch4(fea, num_cluster, lambda, k_rcan);
        time = time + toc;
        cc = cc +1 
        for j=1:length(order_outlier)
            la_rcan=[la_rcan(1:order_outlier(j)-1);num_cluster+1 ;la_rcan(order_outlier(j):end)];
        end
        index=Clustering8Measure(gnd(1:num_sample), la_rcan(1:num_sample));%[Fscore Precision Recall nmi AR Entropy ACC Purity]
        Result_F(r,c) = index(1);
        Result_Pre(r,c) = index(2);
        Result_R(r,c) = index(3);
        Result_NMI(r,c) = index(4);
        Result_AR(r,c) = index(5);
        Result_E(r,c) = index(6);
        Result_ACC(r,c) = index(7);
        Result_PUR(r,c) = index(8);
        c=c+1;
    end
    c=1;
    r=r+1;
end
time =time/cc
Total_Result = Result_ACC + Result_NMI + Result_PUR;
[loc_r, loc_c] = find(Total_Result == max(max(Total_Result)));
ACC = Result_ACC(loc_r(1), loc_c(1))
NMI = Result_NMI(loc_r(1), loc_c(1))
PUR = Result_PUR(loc_r(1), loc_c(1))
save(['...\',Name{i},'_OutlierResult.mat'],'loc_r','loc_c','ACC','NMI','PUR','Result_ACC','Result_NMI','Result_PUR','Result_F','Result_Pre','Result_R','Result_AR','Result_E')
end