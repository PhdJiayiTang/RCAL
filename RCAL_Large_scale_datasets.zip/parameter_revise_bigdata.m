clc
clear
addpath('...\ClusteringMeasure');
for i = 1
Name={'Yale','JAFFE','ORL','UMIST','Reuters','Hdigit','COIL20','COIL100','ALOI','Mfeet','CIFAR10','CIFAR100','FMNIST','MNIST','MNIST2'};
Name2={'Yale_32x32.mat','JAFFE_64x64.mat','ORL_32x32.mat',...
    'UMIST.mat','Reuters.mat',...
    'UCI_Digits.mat','COIL20.mat','COIL100.mat',...
    'ALOI.mat','Mfeat.mat',...
    'cifar10_Per1','cifar100_Per1','fmnist_Per1','MNIST_fea_Per1','MNIST_fea_sort_Per1'};

load(Name2{i})
fea=double(fea);
gnd=double(gnd);
num_cluster=length(unique(gnd));
num_sample=length(gnd);
if size(fea,1)~=num_sample
    fea=fea';
end
r=1;
c=1;
time=0;
cc=1;
for k_rcan = 2:25
    for lambda=[0.00001,0.0001,0.001,0.01,0.1,1,10,100,1000,10000]
        tic
        [ ~,  order_outlier, la_rcan] = RCAL_batch4(fea, num_cluster, lambda, k_rcan);
        time = time + toc;
        cc = cc +1 
        for j=1:length(order_outlier)
            la_rcan=[la_rcan(1:order_outlier(j)-1);num_cluster+1 ;la_rcan(order_outlier(j):end)];
        end
        index=Clustering8Measure(gnd, la_rcan);%[Fscore Precision Recall nmi AR Entropy ACC Purity];
        Result_ACC(r,c) = index(7);
        Result_NMI(r,c) = index(4);
        Result_PUR(r,c) = index(8);
        Result_F(r,c) = index(1);
        Result_Pre(r,c) = index(2);
        Result_Re(r,c) = index(3);
        Result_AR(r,c) = index(5);
        Result_E(r,c) = index(6);
        c=c+1;
    end
    c=1;
    r=r+1;
end
time =time/cc;
Total_Result = Result_ACC + Result_NMI + Result_PUR;
[loc_r, loc_c] = find(Total_Result == max(max(Total_Result)));
ACC = Result_ACC(loc_r(1), loc_c(1));
NMI = Result_NMI(loc_r(1), loc_c(1));
PUR = Result_PUR(loc_r(1), loc_c(1));
save(['...\',Name{i},'_Result.mat'],'loc_r','loc_c','ACC','NMI','PUR',...
    'Result_ACC','Result_NMI','Result_PUR','Result_F','Result_Pre','Result_Re','Result_AR','Result_E')
clear A_rcan  order_outlier la_rcan index Result_ACC Result_NMI Result_PUR distX
end