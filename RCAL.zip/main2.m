clc
clear
for i = 1
Name={'Yale','JAFFE','ORL','UMIST','Reuters','Hdigit','COIL20','COIL100','ALOI','Mfeet'};
Name2={'Yale_32x32.mat','JAFFE_64x64.mat','ORL_32x32.mat',...
    'UMIST.mat','Reuters.mat',...
    'UCI_Digits.mat','COIL20.mat','COIL100.mat',...
    'ALOI.mat','Mfeat.mat'};
load(Name2{i})
num_cluster=length(unique(gnd));
num_sample=length(gnd);
if size(fea,1)~=num_sample
    fea=fea';
end
distX = pdist2(fea, fea, 'euclidean');
r=1;
c=1;
for k_rcan = 2:25
    for lambda=[0.00001,0.0001,0.001,0.01,0.1,1,10,100,1000,10000]
        [ A_rcan,  order_outlier, la_rcan] = RCAL(distX, num_cluster, lambda, k_rcan);
        for j=1:length(order_outlier)
            la_rcan=[la_rcan(1:order_outlier(j)-1);num_cluster+1 ;la_rcan(order_outlier(j):end)];
        end
        index=Clustering8Measure(gnd, la_rcan);
        Result_ACC(r,c) = index(7);
        Result_NMI(r,c) = index(4);
        Result_PUR(r,c) = index(8);
        c=c+1;
    end
    c=1;
    r=r+1;
end
Total_Result = Result_ACC + Result_NMI + Result_PUR;
[loc_r, loc_c] = find(Total_Result == max(max(Total_Result)));
ACC = Result_ACC(loc_r(1), loc_c(1))
NMI = Result_NMI(loc_r(1), loc_c(1))
PUR = Result_PUR(loc_r(1), loc_c(1))
end